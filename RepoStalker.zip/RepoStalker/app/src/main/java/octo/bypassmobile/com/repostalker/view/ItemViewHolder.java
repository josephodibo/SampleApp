package octo.bypassmobile.com.repostalker.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import octo.bypassmobile.com.repostalker.R;
import octo.bypassmobile.com.repostalker.image.ImageLoader;
import octo.bypassmobile.com.repostalker.model.User;

/**
 * Created by josephodibobhahemen on 1/23/17.
 */

public class ItemViewHolder extends RecyclerView.ViewHolder {

    static final int DATA_ROW = 0;

    /**
     * Create view holder item view holder.
     *
     * @param context   the context
     * @param viewGroup the view group
     * @param viewType  the view type
     * @return the item view holder
     */
    static ItemViewHolder createViewHolder(Context context, ViewGroup viewGroup, int viewType) {
        int layoutId = -1;
        switch (viewType) {
            case DATA_ROW:
                layoutId = R.layout.item_row_layout;
                break;
        }

        final View view = LayoutInflater.from(context).inflate(layoutId, viewGroup, false);
        return new ItemViewHolder(view);

    }

    /**
     * Instantiates a new Item view holder.
     *
     * @param itemView the item view
     */
    private ItemViewHolder(View itemView) {
        super(itemView);
    }


    /**
     * Internal binding.
     *
     * @param user                the user
     * @param onItemClickListener the on item click listener
     */
    void internalBinding(final User user, final ViewListener.onItemClickListener onItemClickListener) {
        TextView userName = (TextView) itemView.findViewById(R.id.user_name);
        userName.setText(user.getName());
        ImageView imageView = (ImageView) itemView.findViewById(R.id.image_view);
        ImageLoader.createImageLoader(itemView.getContext())
                .load(user.getProfileURL())
                .fit()
                .placeholder(R.color.colorPrimary)
                .into(imageView);

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onItemClickListener != null) {
                    onItemClickListener.onItemClick(v,user);
                }
            }
        });
    }


}
