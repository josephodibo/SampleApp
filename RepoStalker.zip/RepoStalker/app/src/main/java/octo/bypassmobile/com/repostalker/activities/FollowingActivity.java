package octo.bypassmobile.com.repostalker.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import octo.bypassmobile.com.repostalker.R;
import octo.bypassmobile.com.repostalker.view.TAG;
import octo.bypassmobile.com.repostalker.view.UserFollowingGroupFragment;

/**
 * Created by josephodibobhahemen on 1/23/17.
 */

public class FollowingActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_container);

        if (getIntent().hasExtra(TAG.USER_ID)){
            String id  = getIntent().getStringExtra(TAG.USER_ID);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    UserFollowingGroupFragment.getInstance(id)).commit();
        }

    }

    @Override
    public void setTitle(CharSequence title) {
        super.setTitle(title);
    }
}
