package octo.bypassmobile.com.repostalker.view;

import octo.bypassmobile.com.repostalker.rest.GithubEndpoint;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by josephodibobhahemen on 1/23/17.
 */

public class UserClient {

    private static UserClient userClient = new UserClient();

    public static UserClient getInstance(){
        return userClient;
    }
    /**
     * Gets client.
     *
     * @return the client
     */
    private Retrofit getClient () {
      return new Retrofit.Builder()
               .baseUrl(GithubEndpoint.SERVER)
               .addConverterFactory(GsonConverterFactory.create())
               .client(getOkHttp().build())
               .build();
   }

    /**
     * Github endpoint github endpoint.
     *
     * @return the github endpoint
     */
    public  GithubEndpoint githubEndpoint (){
       return getClient().create(GithubEndpoint.class);
   }

    private OkHttpClient.Builder getOkHttp() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(logging);
        return httpClient;
    }
}
