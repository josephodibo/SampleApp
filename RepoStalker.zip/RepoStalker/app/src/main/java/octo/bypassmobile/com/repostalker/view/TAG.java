package octo.bypassmobile.com.repostalker.view;

import android.support.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by josephodibobhahemen on 1/23/17.
 */

@StringDef({
        TAG.END_POINT,
        TAG.USER_ID
})
@Retention(RetentionPolicy.SOURCE)
public @interface TAG {
    String END_POINT = "END_POINT";
    String USER_ID = "ID";
}
