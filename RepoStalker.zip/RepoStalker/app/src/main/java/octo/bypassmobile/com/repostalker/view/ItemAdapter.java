package octo.bypassmobile.com.repostalker.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import octo.bypassmobile.com.repostalker.model.User;

/**
 * Created by josephodibobhahemen on 1/23/17.
 */

public class ItemAdapter extends RecyclerView.Adapter<ItemViewHolder> {
    private List<User> mUsers = new ArrayList<>();
    private Context mCtx;
    private ViewListener.onItemClickListener onItemClickListener;
    private CustomFilter mFilter;

    /**
     * Instantiates a new Item adapter.
     *
     * @param context the context
     */
    public ItemAdapter(Context context) {
        this.mCtx = context;
    }
    /**
     * Sets data.
     *
     * @param userList the user list
     */
    public void setData(List<User> userList) {
        this.mUsers = userList;
        notifyDataSetChanged();
        mFilter = new CustomFilter(userList, this);

    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return ItemViewHolder.createViewHolder(mCtx,parent,viewType);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        holder.internalBinding(mUsers.get(position), onItemClickListener);
    }

    @Override
    public int getItemCount() {
        return mUsers.size();
    }

    @Override
    public int getItemViewType(int position) {
        return ItemViewHolder.DATA_ROW;
    }

    /**
     * Sets on item click listener.
     *
     * @param onItemClickListener the on item click listener
     */
    public void setOnItemClickListener(ViewListener.onItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void filter(String newText) {
        mFilter.performFiltering(newText);
    }
    public void setList(List<User> list) {
        this.mUsers = list;
    }
}
