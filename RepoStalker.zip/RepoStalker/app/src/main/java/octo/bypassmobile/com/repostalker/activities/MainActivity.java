package octo.bypassmobile.com.repostalker.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.List;

import octo.bypassmobile.com.repostalker.R;
import octo.bypassmobile.com.repostalker.model.User;
import octo.bypassmobile.com.repostalker.view.ItemAdapter;
import octo.bypassmobile.com.repostalker.view.ItemDecorator;
import octo.bypassmobile.com.repostalker.view.TAG;
import octo.bypassmobile.com.repostalker.view.UserClient;
import octo.bypassmobile.com.repostalker.view.ViewListener;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //noinspection ConstantConditions
        setTitle("Members");
        setUpView();
        initAdapter();

    }

    /**
     * Sets up view.
     */
    void setUpView() {
        mRecyclerView = (RecyclerView) findViewById(R.id.main_recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.addItemDecoration(new ItemDecorator(this));
    }

    /**
     * Init adapter.
     */
    void initAdapter(){
        adapter = new ItemAdapter(this);
        adapter.setOnItemClickListener(new ViewListener.onItemClickListener() {
            @Override
            public void onItemClick(View view, Object object) {
                User user = (User) object;
                Intent intent = new Intent(MainActivity.this, FollowingActivity.class);
                intent.putExtra(TAG.USER_ID,user.getName());
                startActivity(intent);
            }
        });
        UserClient.getInstance().githubEndpoint().getOrganizationMember("bypasslane").enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
               adapter.setData(response.body());
            }
            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
            }
        });
        mRecyclerView.setAdapter(adapter);
    }

    @Override
    public void setTitle(CharSequence title) {
        super.setTitle(title);
    }
}
