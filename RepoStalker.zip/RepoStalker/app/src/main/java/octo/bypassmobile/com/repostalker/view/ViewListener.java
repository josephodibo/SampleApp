package octo.bypassmobile.com.repostalker.view;

import android.view.View;

/**
 * Created by josephodibobhahemen on 1/23/17.
 */

public class ViewListener {
    public interface onItemClickListener<T> {
        /**
         * On item click.
         *
         * @param view the view
         * @param object    the t
         */
        void onItemClick(View view, T object);
    }
}
