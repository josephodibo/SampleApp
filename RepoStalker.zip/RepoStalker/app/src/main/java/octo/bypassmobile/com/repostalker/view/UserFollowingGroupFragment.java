package octo.bypassmobile.com.repostalker.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import octo.bypassmobile.com.repostalker.R;
import octo.bypassmobile.com.repostalker.model.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by josephodibobhahemen on 1/19/17.
 */
public class UserFollowingGroupFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private ItemAdapter adapter;
    private SearchView mSearchView;

    /**
     * Instantiates a new User following group fragment.
     */
    public UserFollowingGroupFragment() {
    }

    public  static UserFollowingGroupFragment getInstance(String id){
        UserFollowingGroupFragment fragment = new UserFollowingGroupFragment();
        Bundle args = new Bundle();
        args.putString(TAG.USER_ID,id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.org_fragment_layout, container, false);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.addItemDecoration(new ItemDecorator(getActivity()));

        mSearchView = (SearchView)view.findViewById(R.id.search_view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        init();
        retreiveUserFollowing();
        String user = getArguments().getString(TAG.USER_ID);
        getActivity().setTitle(user +" Following");
    }

    /**
     * Init.
     */
    void init() {
        adapter = new ItemAdapter(getActivity());
        adapter.setOnItemClickListener(new ViewListener.onItemClickListener() {
            @Override
            public void onItemClick(View view, Object object) {
                User user  = (User) object;
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        UserFollowingGroupFragment.getInstance(user.getName())).addToBackStack(null).commit();
            }
        });
        mRecyclerView.setAdapter(adapter);

        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.filter(newText);
                return false;
            }
        });

    }

    void retreiveUserFollowing() {
        String id = getArguments().getString(TAG.USER_ID);
            UserClient.getInstance().githubEndpoint().getFollowingUser(id).enqueue(new Callback<List<User>>() {
                @Override
                public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                    adapter.setData(response.body());
                }
                @Override
                public void onFailure(Call<List<User>> call, Throwable t) {

                }
            });
        }

}
