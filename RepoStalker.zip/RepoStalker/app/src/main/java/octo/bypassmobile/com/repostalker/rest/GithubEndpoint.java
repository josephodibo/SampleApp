package octo.bypassmobile.com.repostalker.rest;


import java.io.Serializable;
import java.util.List;

import octo.bypassmobile.com.repostalker.model.User;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface GithubEndpoint{

    String SERVER = "https://api.github.com";

    @GET("/users/{id}")
    Call<User> getUser(@Path("id") String user);

    @GET("/users/{id}/following")
    Call<List<User>> getFollowingUser(@Path("id") String user);

    @GET("/orgs/{id}/members")
   Call<List<User>> getOrganizationMember(@Path("id") String organization);
}
