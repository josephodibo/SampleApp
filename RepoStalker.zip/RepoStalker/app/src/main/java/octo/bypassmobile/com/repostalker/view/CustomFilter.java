package octo.bypassmobile.com.repostalker.view;

import android.widget.Filter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import octo.bypassmobile.com.repostalker.model.User;

/**
 * Created by josephodibobhahemen on 1/24/17.
 */

public class CustomFilter extends Filter {
    private List<User> unfilteredList;
    private List<User> filteredList;
    private ItemAdapter adapter;


    public CustomFilter(List<User> userList, ItemAdapter itemAdapter) {
        this.unfilteredList = userList;
        this.adapter = itemAdapter;
        this.filteredList = new ArrayList<>();


    }

    protected FilterResults performFiltering(CharSequence constraint) {
        filteredList.clear();
        final FilterResults results = new FilterResults();

        //here you need to add proper items do filteredContactList
        for (final User user : unfilteredList) {
            if (user.getName().toLowerCase().trim().contains(constraint)){
                filteredList.add(user);
            }
        }

        results.values = filteredList;
        results.count = filteredList.size();
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        adapter.setList(filteredList);
        adapter.notifyDataSetChanged();
    }
}
